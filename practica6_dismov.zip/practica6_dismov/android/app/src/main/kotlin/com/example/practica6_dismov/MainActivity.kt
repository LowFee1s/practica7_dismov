package com.example.practica6_dismov

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
