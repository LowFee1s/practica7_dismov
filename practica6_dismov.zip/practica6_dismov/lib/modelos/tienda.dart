import 'package:flutter/cupertino.dart';
import 'package:practica6_dismov/modelos/productos.dart';

class Shop extends ChangeNotifier {
  final List<Product> _shop = [
    //Item1
    Product(
        name: "Producto 1",
        price: 99.99,
        description: "Descripcion....",
    ),
    Product(
      name: "Producto 2",
      price: 99.99,
      description: "Descripcion....",
    ),
    Product(
      name: "Producto 3",
      price: 99.99,
      description: "Descripcion....",
    ),
    Product(
      name: "Producto 4",
      price: 99.99,
      description: "Descripcion....",
    ),
  ];

  //carrito
  List<Product> _cart = [];
  //lista de productos
  List<Product> get shop => _shop;
  //carrito lleno
  List<Product> get cart => _cart;
  //añadir articulos
  void addToCart(Product item) {
    _cart.add(item);
    notifyListeners();
  }

  //eliminar articulo
  void removeFromCart(Product item) {
    _cart.remove(item);
    notifyListeners();

  }

}